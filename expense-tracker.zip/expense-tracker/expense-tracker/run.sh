#!/bin/sh
cd "$(dirname "$0")"
java ExpenseTracker.java
