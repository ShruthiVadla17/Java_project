EXPENSE TRACKER
Java (JDK only) + plain HTML/CSS/JavaScript. No database, no libraries.

HOW TO RUN
  Requires Java 11 or newer (check with:  java -version)

  Windows : double-click run.bat
  Any OS  : open a terminal in this folder and run
              java ExpenseTracker.java
  Then open http://localhost:8080 (it also tries to open the browser itself).
  Different port:  java ExpenseTracker.java 9090

  If you prefer compiling first:
              javac ExpenseTracker.java
              java ExpenseTracker

LOGIN
  Demo account (prefilled on the login page):  demo / demo123

FOLDER LAYOUT
  ExpenseTracker.java   server, REST API, file storage
  web/login.html, login.js   sign-in page
  web/index.html        page structure
  web/style.css         styling
  web/app.js            front-end logic (talks to the API)
  data/                 created on first run; expenses.tsv and budget.txt

API
  POST   /api/login           sign in (username, password)
  POST   /api/logout          sign out
  GET    /api/expenses        list all (needs login)
  POST   /api/expenses        add      (amount, date, category, note)
  PUT    /api/expenses/{id}   update
  DELETE /api/expenses/{id}   remove
  GET    /api/budget          read monthly budget
  PUT    /api/budget          set monthly budget (amount)

To reset all data, stop the server and delete the data folder.
