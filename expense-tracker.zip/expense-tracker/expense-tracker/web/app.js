(function () {
  'use strict';

  // Change these two lines to switch currency symbol / number formatting.
  var CURRENCY = '₹';
  var LOCALE = 'en-IN';

  var CATEGORIES = ['Food', 'Transport', 'Rent', 'Bills', 'Shopping', 'Health', 'Education', 'Entertainment', 'Other'];
  var COLORS = {
    Food: '#c28a1e',
    Transport: '#2f6f9f',
    Rent: '#7a4e8e',
    Bills: '#4e8a4a',
    Shopping: '#b8476b',
    Health: '#1f8a8a',
    Education: '#8a5b3a',
    Entertainment: '#d0602f',
    Other: '#7c8791'
  };

  var money = new Intl.NumberFormat(LOCALE, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  var state = {
    expenses: [],
    budget: 0,
    month: currentMonth(),
    query: '',
    category: 'All',
    editingId: null
  };

  var $ = function (id) { return document.getElementById(id); };

  var banner = $('banner');
  var monthInput = $('month-input');
  var form = $('expense-form');
  var amountInput = $('f-amount');
  var dateInput = $('f-date');
  var categorySelect = $('f-category');
  var noteInput = $('f-note');
  var formTitle = $('form-title');
  var formError = $('form-error');
  var statusLine = $('status');
  var saveBtn = $('save-btn');
  var cancelBtn = $('cancel-btn');
  var budgetForm = $('budget-form');
  var budgetInput = $('f-budget');
  var searchInput = $('q');
  var filterSelect = $('filter-category');
  var statusTimer = null;

  // ---------- small helpers ----------

  function pad(n) { return String(n).padStart(2, '0'); }

  function currentMonth() {
    var d = new Date();
    return d.getFullYear() + '-' + pad(d.getMonth() + 1);
  }

  function today() {
    var d = new Date();
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }

  function fmt(n) { return CURRENCY + money.format(n); }

  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined && text !== null) node.textContent = text;
    return node;
  }

  function colorFor(category) { return COLORS[category] || COLORS.Other; }

  function api(url, options) {
    return fetch(url, options).then(function (res) {
      return res.json().catch(function () { return null; }).then(function (data) {
        if (res.status === 401) { window.location.href = '/login.html'; throw new Error('Please log in again.'); }
        if (!res.ok) throw new Error((data && data.error) || 'Something went wrong. Please try again.');
        return data;
      });
    });
  }

  function say(message) {
    statusLine.textContent = message;
    clearTimeout(statusTimer);
    statusTimer = setTimeout(function () { statusLine.textContent = ''; }, 3000);
  }

  function showBanner(message) {
    banner.textContent = message;
    banner.hidden = false;
  }

  // ---------- data for the selected month ----------

  function monthList() {
    return state.expenses.filter(function (e) { return e.date.slice(0, 7) === state.month; });
  }

  function visibleList() {
    var q = state.query.trim().toLowerCase();
    return monthList().filter(function (e) {
      if (state.category !== 'All' && e.category !== state.category) return false;
      if (q && (e.note + ' ' + e.category).toLowerCase().indexOf(q) === -1) return false;
      return true;
    }).sort(function (a, b) {
      if (a.date !== b.date) return a.date < b.date ? 1 : -1;
      return b.id - a.id;
    });
  }

  function daysCounted() {
    var parts = state.month.split('-').map(Number);
    var daysInMonth = new Date(parts[0], parts[1], 0).getDate();
    var now = new Date();
    if (parts[0] === now.getFullYear() && parts[1] === now.getMonth() + 1) return now.getDate();
    return daysInMonth;
  }

  // ---------- rendering ----------

  function render() {
    var list = monthList();
    var total = list.reduce(function (sum, e) { return sum + e.amount; }, 0);
    renderSummary(list, total);
    renderSplit(list, total);
    renderTable(list.length);
  }

  function renderSummary(list, total) {
    $('spent-total').textContent = fmt(total);
    $('stat-count').textContent = String(list.length);
    $('stat-avg').textContent = fmt(total / daysCounted());

    var meter = $('meter');
    var fill = $('budget-fill');
    var line = $('budget-line');

    if (state.budget > 0) {
      var pct = Math.min(100, (total / state.budget) * 100);
      var over = total > state.budget;
      fill.style.width = pct + '%';
      meter.classList.toggle('over', over);
      meter.setAttribute('aria-valuenow', String(Math.round(pct)));
      line.classList.toggle('over', over);
      line.textContent = over
        ? fmt(total - state.budget) + ' over the ' + fmt(state.budget) + ' budget'
        : fmt(state.budget - total) + ' left of the ' + fmt(state.budget) + ' budget';
    } else {
      fill.style.width = '0%';
      meter.classList.remove('over');
      meter.setAttribute('aria-valuenow', '0');
      line.classList.remove('over');
      line.textContent = 'No budget set. Add one on the left to track your limit.';
    }
  }

  function renderSplit(list, total) {
    var bar = $('split-bar');
    var ul = $('split-list');
    bar.innerHTML = '';
    ul.innerHTML = '';

    if (!list.length) {
      bar.hidden = true;
      $('split-empty').hidden = false;
      $('stat-top').textContent = 'None yet';
      return;
    }
    bar.hidden = false;
    $('split-empty').hidden = true;

    var totals = {};
    list.forEach(function (e) { totals[e.category] = (totals[e.category] || 0) + e.amount; });

    var rows = Object.keys(totals).map(function (name) {
      return { name: name, value: totals[name] };
    }).sort(function (a, b) { return b.value - a.value; });

    $('stat-top').textContent = rows[0].name;

    rows.forEach(function (r) {
      var pct = total > 0 ? (r.value / total) * 100 : 0;

      var seg = el('span', 'seg');
      seg.style.width = pct + '%';
      seg.style.background = colorFor(r.name);
      seg.title = r.name + ': ' + pct.toFixed(0) + '%';
      bar.appendChild(seg);

      var li = el('li');
      var dot = el('span', 'swatch');
      dot.style.background = colorFor(r.name);
      li.appendChild(dot);
      li.appendChild(el('span', 'name', r.name));
      li.appendChild(el('span', 'amt', fmt(r.value)));
      li.appendChild(el('span', 'pct', pct.toFixed(0) + '%'));
      ul.appendChild(li);
    });
  }

  function renderTable(monthCount) {
    var body = $('ledger-body');
    var empty = $('table-empty');
    var rows = visibleList();
    body.innerHTML = '';

    rows.forEach(function (e) {
      var tr = el('tr');
      if (e.id === state.editingId) tr.className = 'editing';

      var p = e.date.split('-').map(Number);
      var dateText = new Date(p[0], p[1] - 1, p[2]).toLocaleDateString(LOCALE, { day: 'numeric', month: 'short' });
      var tdDate = el('td', 'date', dateText);
      tdDate.title = e.date;
      tr.appendChild(tdDate);

      var tdCat = el('td', 'cat');
      var dot = el('span', 'swatch');
      dot.style.background = colorFor(e.category);
      tdCat.appendChild(dot);
      tdCat.appendChild(document.createTextNode(e.category));
      tr.appendChild(tdCat);

      tr.appendChild(el('td', 'note', e.note || ''));
      tr.appendChild(el('td', 'num', fmt(e.amount)));

      var tdAct = el('td', 'row-actions');
      var editBtn = el('button', 'link', 'Edit');
      editBtn.type = 'button';
      editBtn.setAttribute('aria-label', 'Edit ' + e.category + ' expense of ' + fmt(e.amount));
      editBtn.addEventListener('click', function () { startEdit(e.id); });
      var delBtn = el('button', 'link danger', 'Delete');
      delBtn.type = 'button';
      delBtn.setAttribute('aria-label', 'Delete ' + e.category + ' expense of ' + fmt(e.amount));
      delBtn.addEventListener('click', function () { removeExpense(e.id); });
      tdAct.appendChild(editBtn);
      tdAct.appendChild(delBtn);
      tr.appendChild(tdAct);

      body.appendChild(tr);
    });

    if (rows.length === 0) {
      empty.hidden = false;
      empty.textContent = monthCount === 0
        ? 'No expenses for this month yet. Use the form to add your first one.'
        : 'No entries match your search or category filter.';
    } else {
      empty.hidden = true;
    }
  }

  // ---------- form behaviour ----------

  function fillSelects() {
    CATEGORIES.forEach(function (c) {
      var opt = el('option', null, c);
      opt.value = c;
      categorySelect.appendChild(opt);
    });
    ['All'].concat(CATEGORIES).forEach(function (c) {
      var opt = el('option', null, c === 'All' ? 'All categories' : c);
      opt.value = c;
      filterSelect.appendChild(opt);
    });
  }

  function resetForm(keepDateAndCategory) {
    state.editingId = null;
    amountInput.value = '';
    noteInput.value = '';
    if (!keepDateAndCategory) {
      dateInput.value = today();
      categorySelect.value = CATEGORIES[0];
    }
    formTitle.textContent = 'Add an expense';
    saveBtn.textContent = 'Save expense';
    cancelBtn.hidden = true;
    formError.textContent = '';
  }

  function startEdit(id) {
    var e = state.expenses.find(function (x) { return x.id === id; });
    if (!e) return;
    state.editingId = id;
    amountInput.value = e.amount.toFixed(2);
    dateInput.value = e.date;
    categorySelect.value = e.category;
    noteInput.value = e.note;
    formTitle.textContent = 'Edit expense';
    saveBtn.textContent = 'Save changes';
    cancelBtn.hidden = false;
    formError.textContent = '';
    statusLine.textContent = '';
    renderTable(monthList().length);
    amountInput.focus();
    form.scrollIntoView({ block: 'nearest' });
  }

  function removeExpense(id) {
    if (!window.confirm('Delete this expense? This cannot be undone.')) return;
    api('/api/expenses/' + id, { method: 'DELETE' }).then(function () {
      state.expenses = state.expenses.filter(function (x) { return x.id !== id; });
      if (state.editingId === id) resetForm(false);
      render();
      say('Expense deleted.');
    }).catch(function (err) { showBanner(err.message); });
  }

  form.addEventListener('submit', function (ev) {
    ev.preventDefault();
    formError.textContent = '';

    var amount = parseFloat(amountInput.value);
    if (!amountInput.value || isNaN(amount) || amount <= 0) {
      formError.textContent = 'Enter an amount greater than zero.';
      amountInput.focus();
      return;
    }
    if (!dateInput.value) {
      formError.textContent = 'Pick the date of the expense.';
      dateInput.focus();
      return;
    }

    var body = new URLSearchParams({
      amount: amountInput.value,
      date: dateInput.value,
      category: categorySelect.value,
      note: noteInput.value
    });

    var editing = state.editingId !== null;
    var request = editing
      ? api('/api/expenses/' + state.editingId, { method: 'PUT', body: body })
      : api('/api/expenses', { method: 'POST', body: body });

    request.then(function (saved) {
      if (editing) {
        state.expenses = state.expenses.map(function (x) { return x.id === saved.id ? saved : x; });
      } else {
        state.expenses.push(saved);
      }
      state.month = saved.date.slice(0, 7);
      monthInput.value = state.month;
      resetForm(!editing);
      render();
      say(editing ? 'Changes saved.' : 'Expense saved.');
      if (!editing) amountInput.focus();
    }).catch(function (err) {
      formError.textContent = err.message;
    });
  });

  cancelBtn.addEventListener('click', function () {
    resetForm(false);
    renderTable(monthList().length);
  });

  budgetForm.addEventListener('submit', function (ev) {
    ev.preventDefault();
    var value = budgetInput.value === '' ? '0' : budgetInput.value;
    api('/api/budget', { method: 'PUT', body: new URLSearchParams({ amount: value }) })
      .then(function (data) {
        state.budget = data.budget;
        budgetInput.value = data.budget > 0 ? data.budget.toFixed(2) : '';
        render();
        say(data.budget > 0 ? 'Budget updated.' : 'Budget switched off.');
      })
      .catch(function (err) { showBanner(err.message); });
  });

  // ---------- month, search, filter ----------

  function setMonth(value) {
    if (!/^\d{4}-\d{2}$/.test(value)) return;
    state.month = value;
    monthInput.value = value;
    render();
  }

  function shiftMonth(delta) {
    var p = state.month.split('-').map(Number);
    var d = new Date(p[0], p[1] - 1 + delta, 1);
    setMonth(d.getFullYear() + '-' + pad(d.getMonth() + 1));
  }

  $('month-prev').addEventListener('click', function () { shiftMonth(-1); });
  $('month-next').addEventListener('click', function () { shiftMonth(1); });
  monthInput.addEventListener('change', function () { setMonth(monthInput.value); });

  searchInput.addEventListener('input', function () {
    state.query = searchInput.value;
    renderTable(monthList().length);
  });
  filterSelect.addEventListener('change', function () {
    state.category = filterSelect.value;
    renderTable(monthList().length);
  });

  // ---------- CSV export ----------

  function csvCell(value) {
    var s = String(value);
    return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }

  $('export-btn').addEventListener('click', function () {
    var rows = visibleList();
    if (!rows.length) {
      say('There is nothing to export for this view.');
      return;
    }
    var lines = ['Date,Category,Note,Amount'];
    rows.forEach(function (e) {
      lines.push([e.date, e.category, e.note, e.amount.toFixed(2)].map(csvCell).join(','));
    });
    var blob = new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    var link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'expenses-' + state.month + '.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
  });

  // ---------- logout ----------

  $('logout-btn').addEventListener('click', function () {
    fetch('/api/logout', { method: 'POST' }).then(function () {
      window.location.href = '/login.html';
    });
  });

  // ---------- start ----------

  function init() {
    fillSelects();
    dateInput.value = today();
    monthInput.value = state.month;

    api('/api/session').then(function (data) { $('user-name').textContent = 'Signed in as ' + data.user; }).catch(function () {});

    Promise.all([api('/api/expenses'), api('/api/budget')]).then(function (results) {
      state.expenses = results[0];
      state.budget = results[1].budget;
      budgetInput.value = state.budget > 0 ? state.budget.toFixed(2) : '';
      render();
    }).catch(function () {
      showBanner('Cannot reach the Java server. Make sure ExpenseTracker is still running, then reload this page.');
      render();
    });
  }

  init();
})();
