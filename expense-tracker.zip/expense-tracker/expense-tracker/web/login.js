(function () {
  'use strict';

  var form = document.getElementById('login-form');
  var userInput = document.getElementById('l-user');
  var passInput = document.getElementById('l-pass');
  var errorLine = document.getElementById('login-error');
  var button = document.getElementById('login-btn');

  form.addEventListener('submit', function (ev) {
    ev.preventDefault();
    errorLine.textContent = '';

    if (!userInput.value.trim() || !passInput.value) {
      errorLine.textContent = 'Enter both your username and password.';
      return;
    }

    button.disabled = true;
    fetch('/api/login', {
      method: 'POST',
      body: new URLSearchParams({ username: userInput.value, password: passInput.value })
    }).then(function (res) {
      return res.json().catch(function () { return null; }).then(function (data) {
        if (!res.ok) throw new Error((data && data.error) || 'Could not sign in. Please try again.');
        window.location.href = '/';
      });
    }).catch(function (err) {
      errorLine.textContent = err.message === 'Failed to fetch'
        ? 'Cannot reach the Java server. Make sure it is still running.'
        : err.message;
      button.disabled = false;
    });
  });
})();
