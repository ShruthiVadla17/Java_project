import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.awt.Desktop;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Expense Tracker
 *
 * A small web app that runs on the JDK alone: no frameworks, no database.
 * Expenses are kept in memory while the server runs and written to
 * data/expenses.tsv after every change, so nothing is lost on restart.
 *
 * Demo login: username 'demo', password 'demo123' (prefilled on the login page).
 *
 * Run with:   java ExpenseTracker.java            (Java 11 or newer)
 * Other port: java ExpenseTracker.java 9090
 */
public class ExpenseTracker {

    // ---------- configuration ----------

    static final Path DATA_DIR = Paths.get("data");
    static final Path EXPENSE_FILE = DATA_DIR.resolve("expenses.tsv");
    static final Path BUDGET_FILE = DATA_DIR.resolve("budget.txt");
    static final Path WEB_DIR = Paths.get("web").toAbsolutePath().normalize();

    static final Set<String> CATEGORIES = new LinkedHashSet<>(Arrays.asList(
            "Food", "Transport", "Rent", "Bills", "Shopping",
            "Health", "Education", "Entertainment", "Other"));

    static final int MAX_NOTE_LENGTH = 120;
    static final double MAX_AMOUNT = 100_000_000;
    static final int MAX_BODY_BYTES = 10_000;

    // ---------- demo login ----------

    static final String DEMO_USER = "demo";
    static final String DEMO_PASSWORD = "demo123";
    static final String COOKIE_NAME = "session";
    static final Set<String> PUBLIC_FILES = new LinkedHashSet<>(Arrays.asList(
            "/login.html", "/login.js", "/style.css"));
    static final Map<String, String> sessions = new ConcurrentHashMap<>();
    static final SecureRandom RANDOM = new SecureRandom();

    // ---------- in-memory state ----------

    static final Object LOCK = new Object();
    static final List<Expense> expenses = new ArrayList<>();
    static double budget = 0;
    static int nextId = 1;

    static class Expense {
        int id;
        String date;      // yyyy-MM-dd
        String category;
        double amount;
        String note;
    }

    // ---------- entry point ----------

    public static void main(String[] args) throws IOException {
        int port = 8080;
        if (args.length > 0) {
            try {
                port = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                System.out.println("'" + args[0] + "' is not a valid port, using 8080.");
            }
        }

        if (!Files.isDirectory(WEB_DIR)) {
            System.out.println("Cannot find the 'web' folder at " + WEB_DIR);
            System.out.println("Run this program from inside the expense-tracker folder.");
            return;
        }

        loadData();

        HttpServer server;
        try {
            server = HttpServer.create(new InetSocketAddress(port), 0);
        } catch (java.net.BindException e) {
            System.out.println("Port " + port + " is already in use. Try: java ExpenseTracker.java " + (port + 1));
            return;
        }
        server.createContext("/api/login", ExpenseTracker::handleLogin);
        server.createContext("/api/logout", ExpenseTracker::handleLogout);
        server.createContext("/api/session", ExpenseTracker::handleSession);
        server.createContext("/api/expenses", ExpenseTracker::handleExpenses);
        server.createContext("/api/budget", ExpenseTracker::handleBudget);
        server.createContext("/", ExpenseTracker::handleStatic);
        server.start();

        String url = "http://localhost:" + port + "/";
        System.out.println("Expense Tracker is running at " + url);
        System.out.println("Loaded " + expenses.size() + " saved expense(s). Press Ctrl+C to stop.");
        openBrowser(url);
    }

    static void openBrowser(String url) {
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(new URI(url));
            }
        } catch (Throwable ignored) {
            // Not fatal. The URL is printed in the console anyway.
        }
    }

    // ---------- storage ----------

    static void loadData() throws IOException {
        Files.createDirectories(DATA_DIR);

        if (Files.exists(EXPENSE_FILE)) {
            for (String line : Files.readAllLines(EXPENSE_FILE, StandardCharsets.UTF_8)) {
                if (line.isBlank()) continue;
                String[] p = line.split("\t", -1);
                try {
                    Expense e = new Expense();
                    e.id = Integer.parseInt(p[0]);
                    e.date = p[1];
                    e.category = p[2];
                    e.amount = Double.parseDouble(p[3]);
                    e.note = p.length > 4 ? p[4] : "";
                    expenses.add(e);
                    if (e.id >= nextId) nextId = e.id + 1;
                } catch (RuntimeException skip) {
                    System.out.println("Skipping unreadable line in expenses.tsv: " + line);
                }
            }
        }

        if (Files.exists(BUDGET_FILE)) {
            try {
                budget = Double.parseDouble(Files.readString(BUDGET_FILE).trim());
            } catch (RuntimeException ignored) {
                budget = 0;
            }
        }
    }

    // Callers must hold LOCK.
    static void saveExpenses() throws IOException {
        List<String> lines = new ArrayList<>();
        for (Expense e : expenses) {
            lines.add(e.id + "\t" + e.date + "\t" + e.category + "\t"
                    + String.format(Locale.US, "%.2f", e.amount) + "\t" + e.note);
        }
        Path tmp = DATA_DIR.resolve("expenses.tsv.tmp");
        Files.write(tmp, lines, StandardCharsets.UTF_8);
        Files.move(tmp, EXPENSE_FILE, StandardCopyOption.REPLACE_EXISTING);
    }

    // Callers must hold LOCK.
    static void saveBudget() throws IOException {
        Files.writeString(BUDGET_FILE, String.format(Locale.US, "%.2f", budget));
    }

    // ---------- /api/expenses ----------

    static void handleExpenses(HttpExchange ex) throws IOException {
        if (currentUser(ex) == null) { sendJson(ex, 401, error("Please log in first.")); return; }
        try {
            String method = ex.getRequestMethod();
            String rest = ex.getRequestURI().getPath().substring("/api/expenses".length());
            if (rest.startsWith("/")) rest = rest.substring(1);

            if (rest.isEmpty()) {
                if (method.equals("GET")) listExpenses(ex);
                else if (method.equals("POST")) createExpense(ex);
                else sendJson(ex, 405, error("Method not allowed"));
                return;
            }

            int id;
            try {
                id = Integer.parseInt(rest);
            } catch (NumberFormatException e) {
                sendJson(ex, 404, error("Not found"));
                return;
            }

            if (method.equals("PUT")) updateExpense(ex, id);
            else if (method.equals("DELETE")) deleteExpense(ex, id);
            else sendJson(ex, 405, error("Method not allowed"));

        } catch (IllegalArgumentException e) {
            sendJson(ex, 400, error(e.getMessage()));
        } catch (Exception e) {
            e.printStackTrace();
            sendJson(ex, 500, error("The server could not complete that request."));
        }
    }

    static void listExpenses(HttpExchange ex) throws IOException {
        StringBuilder sb = new StringBuilder("[");
        synchronized (LOCK) {
            for (int i = 0; i < expenses.size(); i++) {
                if (i > 0) sb.append(',');
                sb.append(toJson(expenses.get(i)));
            }
        }
        sb.append(']');
        sendJson(ex, 200, sb.toString());
    }

    static void createExpense(HttpExchange ex) throws IOException {
        Expense e = parseExpense(readForm(ex));
        synchronized (LOCK) {
            e.id = nextId++;
            expenses.add(e);
            saveExpenses();
        }
        sendJson(ex, 201, toJson(e));
    }

    static void updateExpense(HttpExchange ex, int id) throws IOException {
        Expense incoming = parseExpense(readForm(ex));
        String response = null;
        synchronized (LOCK) {
            for (Expense e : expenses) {
                if (e.id == id) {
                    e.date = incoming.date;
                    e.category = incoming.category;
                    e.amount = incoming.amount;
                    e.note = incoming.note;
                    saveExpenses();
                    response = toJson(e);
                    break;
                }
            }
        }
        if (response == null) sendJson(ex, 404, error("That expense no longer exists."));
        else sendJson(ex, 200, response);
    }

    static void deleteExpense(HttpExchange ex, int id) throws IOException {
        boolean removed;
        synchronized (LOCK) {
            removed = expenses.removeIf(e -> e.id == id);
            if (removed) saveExpenses();
        }
        if (removed) sendJson(ex, 200, "{\"ok\":true}");
        else sendJson(ex, 404, error("That expense no longer exists."));
    }

    // Validates form input and builds an Expense. Throws IllegalArgumentException
    // with a message that is safe to show to the user.
    static Expense parseExpense(Map<String, String> f) {
        Expense e = new Expense();

        String date = f.getOrDefault("date", "").trim();
        try {
            LocalDate.parse(date);
        } catch (DateTimeParseException ex) {
            throw new IllegalArgumentException("Enter a valid date.");
        }
        e.date = date;

        String category = f.getOrDefault("category", "").trim();
        if (!CATEGORIES.contains(category)) {
            throw new IllegalArgumentException("Choose one of the listed categories.");
        }
        e.category = category;

        double amount;
        try {
            amount = Double.parseDouble(f.getOrDefault("amount", "").trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Enter the amount as a number.");
        }
        if (Double.isNaN(amount) || Double.isInfinite(amount) || amount <= 0) {
            throw new IllegalArgumentException("The amount must be greater than zero.");
        }
        if (amount > MAX_AMOUNT) {
            throw new IllegalArgumentException("That amount is too large.");
        }
        e.amount = Math.round(amount * 100.0) / 100.0;

        String note = f.getOrDefault("note", "").replaceAll("[\\t\\r\\n]+", " ").trim();
        if (note.length() > MAX_NOTE_LENGTH) {
            throw new IllegalArgumentException("Keep the note under " + MAX_NOTE_LENGTH + " characters.");
        }
        e.note = note;

        return e;
    }

    // ---------- /api/budget ----------

    static void handleBudget(HttpExchange ex) throws IOException {
        if (currentUser(ex) == null) { sendJson(ex, 401, error("Please log in first.")); return; }
        try {
            String method = ex.getRequestMethod();
            if (method.equals("GET")) {
                synchronized (LOCK) {
                    sendJson(ex, 200, budgetJson());
                }
            } else if (method.equals("PUT") || method.equals("POST")) {
                Map<String, String> f = readForm(ex);
                double value;
                try {
                    value = Double.parseDouble(f.getOrDefault("amount", "").trim());
                } catch (NumberFormatException e) {
                    throw new IllegalArgumentException("Enter the budget as a number.");
                }
                if (Double.isNaN(value) || Double.isInfinite(value) || value < 0 || value > MAX_AMOUNT) {
                    throw new IllegalArgumentException("Enter a budget between 0 and " + (long) MAX_AMOUNT + ".");
                }
                String json;
                synchronized (LOCK) {
                    budget = Math.round(value * 100.0) / 100.0;
                    saveBudget();
                    json = budgetJson();
                }
                sendJson(ex, 200, json);
            } else {
                sendJson(ex, 405, error("Method not allowed"));
            }
        } catch (IllegalArgumentException e) {
            sendJson(ex, 400, error(e.getMessage()));
        } catch (Exception e) {
            e.printStackTrace();
            sendJson(ex, 500, error("The server could not complete that request."));
        }
    }

    static String budgetJson() {
        return "{\"budget\":" + String.format(Locale.US, "%.2f", budget) + "}";
    }

    // ---------- login / logout ----------

    static String currentUser(HttpExchange ex) {
        String header = ex.getRequestHeaders().getFirst("Cookie");
        if (header == null) return null;
        for (String part : header.split(";")) {
            String[] kv = part.trim().split("=", 2);
            if (kv.length == 2 && kv[0].equals(COOKIE_NAME)) {
                return sessions.get(kv[1]);
            }
        }
        return null;
    }

    static boolean sameText(String a, String b) {
        return MessageDigest.isEqual(a.getBytes(StandardCharsets.UTF_8), b.getBytes(StandardCharsets.UTF_8));
    }

    static void handleLogin(HttpExchange ex) throws IOException {
        try {
            if (!ex.getRequestMethod().equals("POST")) {
                sendJson(ex, 405, error("Method not allowed"));
                return;
            }
            Map<String, String> f = readForm(ex);
            String user = f.getOrDefault("username", "").trim();
            String pass = f.getOrDefault("password", "");
            if (!sameText(user, DEMO_USER) | !sameText(pass, DEMO_PASSWORD)) {
                sendJson(ex, 401, error("Wrong username or password."));
                return;
            }
            byte[] bytes = new byte[24];
            RANDOM.nextBytes(bytes);
            StringBuilder token = new StringBuilder();
            for (byte b : bytes) token.append(String.format("%02x", b));
            sessions.put(token.toString(), user);
            ex.getResponseHeaders().add("Set-Cookie",
                    COOKIE_NAME + "=" + token + "; Path=/; HttpOnly; SameSite=Lax");
            sendJson(ex, 200, "{\"user\":\"" + escape(user) + "\"}");
        } catch (IllegalArgumentException e) {
            sendJson(ex, 400, error(e.getMessage()));
        } catch (Exception e) {
            e.printStackTrace();
            sendJson(ex, 500, error("The server could not complete that request."));
        }
    }

    static void handleLogout(HttpExchange ex) throws IOException {
        String header = ex.getRequestHeaders().getFirst("Cookie");
        if (header != null) {
            for (String part : header.split(";")) {
                String[] kv = part.trim().split("=", 2);
                if (kv.length == 2 && kv[0].equals(COOKIE_NAME)) sessions.remove(kv[1]);
            }
        }
        ex.getResponseHeaders().add("Set-Cookie", COOKIE_NAME + "=; Path=/; Max-Age=0");
        sendJson(ex, 200, "{\"ok\":true}");
    }

    static void handleSession(HttpExchange ex) throws IOException {
        String user = currentUser(ex);
        if (user == null) sendJson(ex, 401, error("Not logged in."));
        else sendJson(ex, 200, "{\"user\":\"" + escape(user) + "\"}");
    }

    // ---------- static files ----------

    static void handleStatic(HttpExchange ex) throws IOException {
        try {
            String path = ex.getRequestURI().getPath();
            if (path.equals("/")) path = "/index.html";

            // Everything except the login page and its assets needs a session.
            if (!PUBLIC_FILES.contains(path) && currentUser(ex) == null) {
                ex.getResponseHeaders().set("Location", "/login.html");
                ex.sendResponseHeaders(302, -1);
                ex.close();
                return;
            }
            // Already logged in? Skip the login page.
            if (path.equals("/login.html") && currentUser(ex) != null) {
                ex.getResponseHeaders().set("Location", "/");
                ex.sendResponseHeaders(302, -1);
                ex.close();
                return;
            }

            Path file = WEB_DIR.resolve(path.substring(1)).normalize();
            if (!file.startsWith(WEB_DIR) || !Files.isRegularFile(file)) {
                send(ex, 404, "text/plain; charset=utf-8", "Page not found".getBytes(StandardCharsets.UTF_8));
                return;
            }
            send(ex, 200, contentType(file.getFileName().toString()), Files.readAllBytes(file));
        } catch (Exception e) {
            send(ex, 404, "text/plain; charset=utf-8", "Page not found".getBytes(StandardCharsets.UTF_8));
        }
    }

    static String contentType(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".html")) return "text/html; charset=utf-8";
        if (n.endsWith(".css")) return "text/css; charset=utf-8";
        if (n.endsWith(".js")) return "application/javascript; charset=utf-8";
        if (n.endsWith(".svg")) return "image/svg+xml";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".ico")) return "image/x-icon";
        return "application/octet-stream";
    }

    // ---------- helpers ----------

    static Map<String, String> readForm(HttpExchange ex) throws IOException {
        byte[] raw = ex.getRequestBody().readAllBytes();
        if (raw.length > MAX_BODY_BYTES) {
            throw new IllegalArgumentException("That request is too large.");
        }
        Map<String, String> map = new HashMap<>();
        String body = new String(raw, StandardCharsets.UTF_8);
        if (body.isEmpty()) return map;

        for (String pair : body.split("&")) {
            int eq = pair.indexOf('=');
            String key = eq < 0 ? pair : pair.substring(0, eq);
            String value = eq < 0 ? "" : pair.substring(eq + 1);
            map.put(URLDecoder.decode(key, StandardCharsets.UTF_8),
                    URLDecoder.decode(value, StandardCharsets.UTF_8));
        }
        return map;
    }

    static String toJson(Expense e) {
        return "{\"id\":" + e.id
                + ",\"date\":\"" + e.date + "\""
                + ",\"category\":\"" + escape(e.category) + "\""
                + ",\"amount\":" + String.format(Locale.US, "%.2f", e.amount)
                + ",\"note\":\"" + escape(e.note) + "\"}";
    }

    static String error(String message) {
        return "{\"error\":\"" + escape(message) + "\"}";
    }

    static String escape(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"':  sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        return sb.toString();
    }

    static void sendJson(HttpExchange ex, int status, String json) throws IOException {
        send(ex, status, "application/json; charset=utf-8", json.getBytes(StandardCharsets.UTF_8));
    }

    static void send(HttpExchange ex, int status, String type, byte[] body) throws IOException {
        ex.getResponseHeaders().set("Content-Type", type);
        ex.getResponseHeaders().set("Cache-Control", "no-store");
        if (ex.getRequestMethod().equals("HEAD")) {
            ex.sendResponseHeaders(status, -1);
            ex.close();
            return;
        }
        ex.sendResponseHeaders(status, body.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(body);
        }
    }
}
