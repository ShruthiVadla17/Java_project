@echo off
cd /d "%~dp0"
java ExpenseTracker.java
pause
